totalgrosspayment = 0
counter = 0

choice = input("Do you want to do this program?(Yes/No):")
while choice == "Yes" or choice == "Yes":
  lastname = input("Enter last name of Employee:")
  hoursworked = int(input("Enter hours you worked:"))
  payrate = int(input("Enter pay rate:"))

if hoursworked > 40:
  grosspay = hoursworked * (payrate/2)
else:
  grosspay = hoursworked * payrate

totalgrosspayment = grosspaycounter + 1;
print(lastname,"your gross pay is:",grosspay)
choice = input("Do you want to do this program?(Yes/No):")
averagegrosspayment = totalgrosspayment/counter
print("The average gross payment is :", averagegrosspayment)
