totalgrosspayment = 0
counter = 0

choice = input("Do you want to do this program?(Yes/No):")
while choice == "Yes" or choice == "Yes":
  quantity = input("Enter quantity of item:")
  price = int(input("Enter price of item:"))

extendedprice = (quantity * price)

if extendedprice > 10000:
  discount = (.25 * extendedprice)

total = extendedprice * .25
print(quantity,"your quantity is:",quantity)
choice = input("Do you want to do this program?(Yes/No):")
